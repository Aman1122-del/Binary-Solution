filename = "contacts.txt"   # file that contain numbers and contacts
print(f"Successfully loaded file: ",{filename})

# Loading contacts from the file
contacts = {}   # create a dictionary
file = open(filename, 'r')  # open the file to read
lines = file.readlines()    # read all the lines from file 
for line in lines:          # for loop for each line 
    line = line.strip()     # remove extra spaces from the line 
    if line:                # sures the line is not empty
        parts = line.split(",") # split the line into two columns name and contacts
        contacts[parts[0]] = parts[1]   # store the contacts in the dictionary
file.close()    # close the file after reading

while True:     # to run the programm as user want
    print("--- Contact List Manager ---")
# menu option to choose 
    print("1. Display Contacts")    # to display all the congtacts saved in file 
    print("2. Add Contact")         # to add a new contact to a file 
    print("3. Update Contact")      # to update the existing contact
    print("4. Search Contact")      # search a contatc by name 
    print("5. Exit")                # to exit/stop the program
    print("Choose an option (1-5):")
    choice = input().strip()        # remove extra spaces from the user input

    if choice == "1":       # by pressing 1, display all contacts 
        if len(contacts) == 0:      # if contacts are not found then print no contacts to display
            print("No contacts to display.")
        else:                       # if file contains contacts list then print 
            print("--- Contact List ---")
            for name in contacts:   # for loop for each contact
                print(name + ": " + contacts[name]) # print contacts with name 

    elif choice == "2":     # by pressing 2 to add a new contacts
        print("Enter the name of the contact:")     # ask to enter the name 
        name = input().strip()      # remove extra spaces from the user input
        while name == "":           # check the name is not empty
            print("Name cannot be empty. Enter the name again:")
            name = input().strip()  # remove extra spaces from the user input
        if name in contacts:        # checks if the name is already saved
            print("This name already exists. Use the update option to modify the contact.")
            continue
        print("Enter the phone number of the contact:") # ask to enter the number 
        phone = input().strip()     # remove extra spaces from the user input
        while not phone.isdigit():  # number should be only digits
            print("Phone number must contain only digits. Enter again:")
            phone = input().strip() # remove extra spaces from the user input
        contacts[name] = phone      # add a new contact to dictionary
        print("Contact added successfully.")
        file = open(filename, 'w')  # open the file to write
        for contact_name in contacts:   # for loop for each contact
            file.write(contact_name + ", " + contacts[contact_name] + "\n") # to write name and contact number in the file
        file.close() # file closed after writing

    elif choice == "3":     # by pressing 3, to update contact
        print("Enter the name of the contact to update:")       # ask to enter the name of existed contact
        name = input().strip()       # remove extra spaces from the user input
        if name not in contacts:    # checks if name is not in the contact list then print contact not found
            print("Contact not found.")
            continue
        print("Current phone number: " + contacts[name]) # if the contact found then print the current number of search name
        print("Enter the new phone number:") # enter the new number that to update 
        phone = input().strip()     # remove extra spaces from the user input
        while not phone.isdigit():  # number should be only digits
            print("Phone number must contain only digits. Enter again:")
            phone = input().strip() # remove extra spaces from the user input
        contacts[name] = phone      # contact updated
        print("Contact updated successfully.")
        file = open(filename, 'w')  # open the file to write
        for contact_name in contacts:    # for loop for each contact
            file.write(contact_name + ", " + contacts[contact_name] + "\n") # to write name and contact number in the file
        file.close()    # file closed after writing

    elif choice == "4": # by pressing 4, to seach a contact by name 
        print("Enter the name to search:")       # ask to enter the name
        name = input().strip()      # remove extra spaces from the user input
        if name in contacts:        # checks if the contacts exit 
            print(name + ": " + contacts[name])      # print the searched number
        else:                        # if not print not found
            print("Contact not found.")

    elif choice == "5":     # by pressing 5, to exit the program
        print("Exiting the Contact List Manager. Goodbye!")
        break

    else:       # if entered numner is invalid 
        print("Invalid choice. Please enter a number between 1 and 5.")
